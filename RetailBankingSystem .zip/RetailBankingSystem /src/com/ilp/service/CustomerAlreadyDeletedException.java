package com.ilp.service;

public class CustomerAlreadyDeletedException extends Exception {

}
