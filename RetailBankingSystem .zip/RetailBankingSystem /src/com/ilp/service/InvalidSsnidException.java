package com.ilp.service;

public class InvalidSsnidException extends Exception {

}
