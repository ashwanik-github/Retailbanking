package com.ilp.service;

public class CustomerNotFoundException extends Exception {

}
