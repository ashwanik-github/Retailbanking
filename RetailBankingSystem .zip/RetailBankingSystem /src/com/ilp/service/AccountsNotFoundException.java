package com.ilp.service;

public class AccountsNotFoundException extends Exception {

}
