package com.ilp.service;

public class InsufficientbalanceException extends Exception {

}
