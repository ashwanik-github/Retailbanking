package com.ilp.service;

public class CustomerInvalidException extends Exception {

}
