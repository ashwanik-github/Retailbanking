package com.ilp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.ilp.bean.Account;
import com.ilp.bean.Customer;
import com.ilp.util.DatabaseUtil;

public class DAO {

	
	Connection con=null;
	PreparedStatement ps=null;
	PreparedStatement ps1=null;
	ResultSet rs= null;
	ResultSet rs1= null;
	private static String status=null;
	private static String Message=null;
	//FOR LOGIN CHECK
	public String LoginCheck(String user,String pass) 
	{
		Connection con=null;
		PreparedStatement ps=null;
		PreparedStatement ps1=null;
		ResultSet rs= null;
		String username="";
		String password="";
		
		boolean flag=false;
		String dept="fail";
		try
		{
		con=DatabaseUtil.getConnection();
		String str1="select Username,Password from Login";
		ps=con.prepareStatement(str1);
		rs=ps.executeQuery();
		while(rs.next())
		{
			username=rs.getString(1);
			password=rs.getString(2);
			if(username.equals(user) && password.equals(pass))
			{
				flag=true;
				
			}
		}
		if(flag==true)
		{
			String str2="select Department from Login where Username=?";
			System.out.println(str2);
			ps1=con.prepareStatement(str2);
			ps1.setString(1,user);
			rs = ps1.executeQuery();
			while(rs.next())
			{
				
				dept=rs.getString(1);
				System.out.println(dept);
			}
		}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
		DatabaseUtil.closeStatement(ps);	
		DatabaseUtil.closeStatement(ps1);
		DatabaseUtil.closeConnection(con);
		}
		
		return dept;
		
	}
	
	
	//FOR ADDING CUSTOMER
	public boolean addCustomer(Customer c) 
	{
		Connection con=null;
		PreparedStatement ps=null;
		PreparedStatement ps1=null;
		PreparedStatement ps2=null;
		ResultSet rs= null;
		String username="";
		String password="";
		int i=0;
		boolean flag = false;
		try{
			
		
		con=DatabaseUtil.getConnection();
		String str="insert into CustomerTable_GroupB values(?,CUSTID.nextval,?,?,?,?,?,?)";
		ps=con.prepareStatement(str);
		ps.setLong(1, c.getSsnid());
		ps.setString(2, c.getName());
		ps.setInt(3, c.getAge());
		ps.setString(4, c.getAddline1());
		ps.setString(5, c.getAddline2());
		ps.setString(6, c.getCity());
		ps.setString(7, c.getState());
		i=ps.executeUpdate();
		
	if(i>0)
	{
		long custid=0;
		String query1="Select max(CustID) from CustomerTable_GroupB";
		ps1=con.prepareStatement(query1);
		rs=ps1.executeQuery();
		while(rs.next())
		{
			custid=rs.getLong(1);
		}
		String query="Insert into CustomerStatus_GroupB values(?,?,?,?,CURRENT_TIMESTAMP)";
		ps1=con.prepareStatement(query);
		ps1.setLong(1, c.getSsnid());
		ps1.setLong(2, custid);
		status="created";
		ps1.setString(3, status);
		Message="Customer created";
		ps1.setString(4, Message);
		int j=ps1.executeUpdate();	
		flag = true;
	}
	else 
		flag = false;
	}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
	//FOR FETCHING CUSTOMER SSNID
	public Customer fetchssnid(long SSNId)
	{
		Connection con=null;
		PreparedStatement ps=null;
		
		ResultSet rs= null;
		int i=0;
		con=DatabaseUtil.getConnection();
		Customer c=null;
		String str="select * from  CustomerTable_GroupB where SSNId=? ";
		try {
			ps=con.prepareStatement(str);
			ps.setLong(1, SSNId);
			rs=ps.executeQuery();
			while(rs.next())
			{
				 c=new Customer(rs.getLong(1), rs.getLong(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8));
				 System.out.println(c.getCustid());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(c);
		return c;		
	}
	
	
	//FOR FETCHING CUSTOMER ID
	public Customer fetchcustid(long custid)
	{
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs= null;
		int i=0;
		con=DatabaseUtil.getConnection();
		Customer c=null;
		String str="select * from  CustomerTable_GroupB where CustID=? ";
		try {
			ps=con.prepareStatement(str);
			ps.setLong(1, custid);
			rs=ps.executeQuery();
			while(rs.next())
			{
				 c=new Customer(rs.getLong(1), rs.getLong(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8));
				 System.out.println(c.getCustid());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(c);
		return c;
		
		
				
	}
	
	
	public boolean AddAccount(long custid,String accountType,double bal) 
	{
		int i=0;
		long cid=0;
		String msg=null;
		
		
		
			con=DatabaseUtil.getConnection();
			String query="Select CustID from CustomerTable_GroupB where CustID=?";
			try
			{
				ps=con.prepareStatement(query);
				ps.setLong(1, custid);
				rs=ps.executeQuery();
				while(rs.next())
				{
					cid=rs.getLong(1);
					
					String query2="insert into CustomerAccount(AccountID,CustID,AccountType,Balance,Status) values(ACCOUNTID_GroupB.nextval,?,?,?,?)";
					try
					{
						String s="active";
						ps1=con.prepareStatement(query2);
						ps1.setLong(1, cid);
						ps1.setString(2, accountType);
						ps1.setDouble(3, bal);
						ps1.setString(4, s);
						i=ps1.executeUpdate();
					}
					catch(SQLException ex)
					{
						ex.printStackTrace();
					}
				}
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			if(i>0)
				return true;
			else
				return false;
				
		
		
		
	}
	
	//FOR UPDATING CUSTOMER
	public boolean Update(Customer c)
	{
		Connection con=null;
		PreparedStatement ps=null;

		ResultSet rs= null;
		int i=0;
		con=DatabaseUtil.getConnection();
		String query="update CustomerTable_GroupB set  SSNID=?,CustID=?,Name=?,Age=?,Addressline1=?,Addressline2=?,City=?,State=? where SSNID=?";
		try {
			ps=con.prepareStatement(query);
			ps.setLong(1, c.getSsnid());
			ps.setLong(2, c.getCustid());
			ps.setString(3, c.getName());
			ps.setInt(4, c.getAge());
			ps.setString(5, c.getAddline1());
			ps.setString(6, c.getAddline2());
			ps.setString(7, c.getCity());
			ps.setString(8, c.getState());
			ps.setLong(9, c.getSsnid());
			
			i=ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(i>0)
		{
			String query1="Update CustomerStatus_GroupB set Status=?,Message=?,LastUpdated=CURRENT_TIMESTAMP";
			try {
				ps=con.prepareStatement(query1);
			
			status="Updated";
			Message="Customer detail updated";
			ps.setString(1, status);
			ps.setString(2, Message);
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return true;
		}
		else
		{
			return false;
		}		
	}
	
	//FOR DELETE CHECK
	
	
	
	//FOR DELETING ACCOUNT
	public int checkcustid(long custid) throws SQLException
	{
		int i=0;
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		ResultSet rs1=null;
		con=DatabaseUtil.getConnection();
		String str= "select CustID from CustomerTable_GroupB where CustID = ?";
		ps=con.prepareStatement(str);
		ps.setLong(1, custid);
		rs=ps.executeQuery();
		while(rs.next())
		{
			long cust=rs.getLong(1);
			String s="Select Status from CustomerAccount where CustID=?";
			ps1=con.prepareStatement(s);
			ps1.setLong(1, custid);
			rs1=ps1.executeQuery();
			while(rs1.next())
			{
				if(rs1.getString(1).equals("inactive"))
				{
					i=0;
				}
				else
					i++;
			}
			
		}
		return i;
	}
	
	
	//FOR DELETING ACCOUNT
	public String deletecustomer(long custid) throws SQLException
	{
		Connection con=null;
		PreparedStatement ps=null;
		PreparedStatement ps1=null;
		PreparedStatement ps2=null;
		ResultSet rs= null;
		ResultSet rs1= null;
		long accid=0;
		int n=0;
		boolean flag=false;
		String statusrole=null;
		
		con=DatabaseUtil.getConnection();
		String str="select AccountID from CustomerAccount where CustID=?";
		ps=con.prepareStatement(str);
		ps.setLong(1, custid);
		rs=ps.executeQuery();
		while(rs.next())
		{
			accid=rs.getLong(1);
			String st="update CustomerAccount set Status=? where AccountID=?";
			ps1=con.prepareStatement(st);
			ps1.setString(1, "inactive");
			ps1.setLong(2, accid);
			n=ps1.executeUpdate();
			if(n>0)
			{
				statusrole="inactive";
				String query1="Update CustomerStatus_GroupB set Status=?,Message=?,LastUpdated=CURRENT_TIMESTAMP";
				try {
					ps=con.prepareStatement(query1);
				
				status="Deleted";
				Message="Customer Deleted";
				ps.setString(1, status);
				ps.setString(2, Message);
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		return statusrole;
	}
	
	
	
	
	public boolean checkSsnid(long ssnid)
	{
		con=DatabaseUtil.getConnection();
		boolean flag=false;
		String query="Select ssnid from CustomerTable_GroupB where ssnid=?";
		try {
			ps=con.prepareStatement(query);
			ps.setLong(1, ssnid);
			rs=ps.executeQuery();
			while(rs.next())
			{
				flag=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(flag);
		return flag;
	}
	
	public boolean checkCustomerID(long custid)
	{
		con=DatabaseUtil.getConnection();
		boolean flag=false;
		String query="Select custid from CustomerTable_GroupB where custid=?";
		try {
			ps=con.prepareStatement(query);
			ps.setLong(1, custid);
			rs=ps.executeQuery();
			while(rs.next())
			{
				flag=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(flag);
		return flag;
	}
	
	public boolean deleteBySsnid(long ssnid)
	{
		con=DatabaseUtil.getConnection();
		int i=0;
		boolean flag=false;
		String query="select CustID from  CustomerTable_GroupB where SSNID=?";
		try {
			ps=con.prepareStatement(query);
			ps.setLong(1, ssnid);
			rs=ps.executeQuery();
			while(rs.next())
			{
				long custid=rs.getLong(1);
				String query2="Update CustomerAccount set Status='inactive' where custid=?";
				ps1=con.prepareStatement(query2);
				ps1.setLong(1, custid);
				i=ps1.executeUpdate();	
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(i>0)
		{
			flag=true;
		}
		
		return flag;
		
	}
	public boolean deleteByCustid(long custid)
	{
		con=DatabaseUtil.getConnection();
		int i=0;
		boolean flag=false;
		try
		{
				String query2="Update CustomerAccount set Status='inactive' where custid=?";
				ps1=con.prepareStatement(query2);
				ps1.setLong(1, custid);
				i=ps1.executeUpdate();	
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(i>0)
		{
			System.out.println("abc");
			flag=true;
		}
		
		return flag;
		
	}
	
	
	public ArrayList<Account> getSsnidAccountList(long ssnid)
	{
		ArrayList<Account> alist=new ArrayList<Account>();
		con=DatabaseUtil.getConnection();
		String query="Select custid from CustomerTable_GroupB where ssnid=?";
		try {
			ps=con.prepareStatement(query);
			ps.setLong(1, ssnid);
			rs=ps.executeQuery();
			while(rs.next())
			{
				long custid=rs.getLong(1);
				String query2="Select * from  CustomerAccount where custid=? and Status=?";
				ps1=con.prepareStatement(query2);
				ps1.setLong(1, custid);
				ps1.setString(2, "active");
				rs1=ps1.executeQuery();
				while(rs1.next())
				{
					System.out.println(rs1.getTimestamp(5).toString());
					Account ac=new Account(rs1.getLong(1), rs1.getLong(2), rs1.getString(3), rs1.getDouble(4), rs1.getTimestamp(5).toString(), rs1.getTimestamp(6).toString(), rs1.getString(7));
					
					alist.add(ac);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return alist;
	}
	
	
	public ArrayList<Account> getCustidAccountList(long custid)
	{
		ArrayList<Account> alist=new ArrayList<Account>();
		con=DatabaseUtil.getConnection();
		
				String query2="Select * from  CustomerAccount where custid=? ";
				try
				{
					ps1=con.prepareStatement(query2);
					ps1.setLong(1, custid);
					rs1=ps1.executeQuery();
					while(rs1.next())
					{
						
						Account ac=new Account(rs1.getLong(1), rs1.getLong(2), rs1.getString(3), rs1.getDouble(4), rs1.getTimestamp(5).toString(), rs1.getTimestamp(6).toString(), rs1.getString(7));
						alist.add(ac);
					}
				}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return alist;
	}
	public Account getAccountObj(long accid)
	{
		con=DatabaseUtil.getConnection();
		Account ac=null;
		String query2="Select * from  CustomerAccount where AccountID=? ";
		try
		{
			ps=con.prepareStatement(query2);
			ps.setLong(1, accid);
			rs1=ps.executeQuery();
			while(rs1.next())
			{
				
				 ac=new Account(rs1.getLong(1), rs1.getLong(2), rs1.getString(3), rs1.getDouble(4), rs1.getTimestamp(5).toString(), rs1.getTimestamp(6).toString(), rs1.getString(7));
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ac;
	}
		
	
	
	public double getLatestBal(Account acObj,Double withdAmt) {
		con=DatabaseUtil.getConnection();
		double oldbal=0;
		double laetstbal=0;
		int chk = 0;
		System.out.println(acObj.getAccountID());
		String query2="select Balance from CustomerAccount where AccountID=?";
		try
		{
			ps=con.prepareStatement(query2);
			ps.setLong(1, acObj.getAccountID());
			rs=ps.executeQuery();
			while(rs.next())
			{
				oldbal=rs.getDouble(1);
				if(oldbal>=withdAmt)
				{
					
					String query="update CustomerAccount set Balance= Balance-? where AccountID=?";
					try
					{
						ps1=con.prepareStatement(query);
						ps1.setDouble(1, withdAmt);
						ps1.setLong(2, acObj.getAccountID());
						chk = ps1.executeUpdate();
						if(chk>0){
//							String query3="select Balance from CustomerAccount where AccountID=?";
							try
							{
								ps=con.prepareStatement(query2);
								ps.setDouble(1, acObj.getAccountID());
								rs=ps.executeQuery();
								while(rs.next())
								{
									laetstbal=rs.getDouble(1);
								}
							}
							catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
					catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
					
				
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return laetstbal;
		
	}


	public double getLatestBalAfterDeposit(Account acObj, double depoAmt) {
		con=DatabaseUtil.getConnection();
		double oldbal=0;
		double laetstbal=0;
		int chk = 0;
		System.out.println(acObj.getAccountID());
		String query2="select Balance from CustomerAccount where AccountID=?";
		try
		{
			ps=con.prepareStatement(query2);
			ps.setLong(1, acObj.getAccountID());
			rs=ps.executeQuery();
			while(rs.next())
			{
				oldbal=rs.getDouble(1);
				if(oldbal>=depoAmt)
				{
					
					String query="update CustomerAccount set Balance= Balance+? where AccountID=?";
					try
					{
						ps1=con.prepareStatement(query);
						ps1.setDouble(1, depoAmt);
						ps1.setLong(2, acObj.getAccountID());
						chk = ps1.executeUpdate();
						if(chk>0){
//							String query3="select Balance from CustomerAccount where AccountID=?";
							try
							{
								ps=con.prepareStatement(query2);
								ps.setDouble(1, acObj.getAccountID());
								rs=ps.executeQuery();
								while(rs.next())
								{
									laetstbal=rs.getDouble(1);
								}
							}
							catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
					catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
					
				
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return laetstbal;
	}
	public double getAccountBalance(long accid)
	{
		long balance=0;
		con=DatabaseUtil.getConnection();
		Account ac=null;
		String query2="Select Balance from  CustomerAccount where AccountID=? ";
		try {
			ps=con.prepareStatement(query2);
			ps.setLong(1,accid);
			rs=ps.executeQuery();
			while(rs.next())
			{
				balance = rs.getLong(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return balance;
	}
	public void transfer(long accid,double amount)
	{
		try
		{
		int n=0;
		Connection con=null;
		PreparedStatement ps=null;
		con=DatabaseUtil.getConnection();
		Account ac=null;
		String str="update CustomerAccount set Balance=? where AccountID=?";
		ps=con.prepareStatement(str);
		ps.setDouble(1,amount);
		ps.setLong(2,accid);
		n=ps.executeUpdate();
		if(n>0)
		{
		System.out.println("The account is updated with account id"+accid+ " with balance " +amount );
		}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	
}
