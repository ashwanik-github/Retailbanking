package com.ilp.bean;

public class CustomerStatus {
	private long SSNID;
	private long CustID;
	private String Status;
	private String Message;
	private String Last_Updated;
	public CustomerStatus(long sSNID, long custID, String status,
			String message, String last_Updated) {
		super();
		SSNID = sSNID;
		CustID = custID;
		Status = status;
		Message = message;
		Last_Updated = last_Updated;
	}
	public long getSSNID() {
		return SSNID;
	}
	public void setSSNID(long sSNID) {
		SSNID = sSNID;
	}
	public long getCustID() {
		return CustID;
	}
	public void setCustID(long custID) {
		CustID = custID;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getMessage() {
		return Message;
	}
	public void setMessage(String message) {
		Message = message;
	}
	public String getLast_Updated() {
		return Last_Updated;
	}
	public void setLast_Updated(String last_Updated) {
		Last_Updated = last_Updated;
	}
	

}
