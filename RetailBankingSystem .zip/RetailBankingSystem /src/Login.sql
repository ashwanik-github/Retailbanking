create table Login
(
Username varchar(10) primary key,
Password varchar(10) not null,
Department varchar(10) not null
)
-------        -------------      ------------          ---------------
insert into Login values('harshit','abc123','executive');
insert into Login values('harsh','abc123','executive');
insert into Login values('harsih','abc123','executive');
insert into Login values('ajay','abc123','cashier');
insert into Login values('atul','abc123','cashier');
insert into Login values('aman','abc123','cashier');

-------        -------------      ------------          ---------------

drop table Login

-------        -------------      ------------          ---------------

create SEQUENCE CUSTID
start with 100000000
increment by 1
MAXVALUE 999999999;


create SEQUENCE ACCOUNTID_GroupB
start with 900000000
increment by 10
MAXVALUE 999999999;

-------        -------------      ------------          ---------------

select Username,Password from Login
select Department from Login where Username='harshit'
select Department from Login where Username='harshit'
select * from LOGIN;
-------------------------------------------------------------------------

create table CustomerTable_GroupB
(
SSNID number(9) not null,
CustID number(9) primary key,
Name varchar2(20) not null,
Age int not null,
Addressline1 varchar2(20) not null,
Addressline2 varchar2(20) not null,
City varchar2(15) not null,
State varchar2(15) not null
)

create table CustomerAccount
(
	AccountID number(9) primary key,
	CustID number(9) not null,
	AccountType varchar(10) not null,
	Balance number(10,2) not null,
	Start_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	End_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	Status varchar(10) not null,
	foreign key(CustID) references CustomerTable_GroupB(CustID)
)
----------------------------------------------------------------------------
create table CustomerStatus_GroupB
(
	SSNID number(9) primary key,
	CustID number(9) not null,
	Status varchar(10) not null,
	Message varchar(10),
	Last_Updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	foreign key(CustID) references CustomerTable_GroupB(CustID)
	
)
----------------------------------------------------------------------
create table AccountStatus_GroupB
(
	AccountID number(9) primary key,
	CustID number(9) not null,
	AccountType varchar(10) not null,
	Status varchar(10) not null,
	Message varchar(10),
	Last_Updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	foreign key(CustID) references CustomerTable_GroupB(CustID)
	
)
----------------------------------------------------------------------

drop table CustomerAccount

select * from CustomerStatus_GroupB
select * from CustomerTable_GroupB
select * from CustomerAccount
update CustomerTable_GroupB set values (SSNID=123456789,CustID=741852963,Name='anu',Age=22,Addressline1='abc',Addressline2='def',City='xyz',State='pqr') where SSNID=369852147
delete from RetailCustomer
select * from RetailCustomer 
select * from  RetailCustomer where SSNId=123456789 
drop table CustomerTable_GroupB
select * from LOGIN
Select * from  CustomerAccount where custid=100000005
Update CustomerAccount set Status='active' where custid=100000005



